<template>
	<div id="app">
		<router-view></router-view>
	</div>
</template>

<script>
	import HelloWorld from './components/HelloWorld.vue'
	import Login from './components/Login.vue'
	import Manager from './components/Manager.vue'
	import Tenant from './components/Tenant.vue'
	import Waiter from './components/Waiter.vue'
	export default {
		name: 'App',
		components: {
			HelloWorld,
			Login,
			Manager,
			Tenant,
			Waiter
		}
		// beforeMount: function() {
		// 	this.$router.push('/')
		// }
	}
</script>

<style>
	#app {
		font-family: 'Avenir', Helvetica, Arial, sans-serif;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
		text-align: center;
		color: #2c3e50;
		margin-top: 60px;
	}
</style>
